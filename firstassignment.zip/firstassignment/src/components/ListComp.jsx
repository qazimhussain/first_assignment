function ListComp({title,name,checked,handleItemChange}) {
    return ( 
        <div className="list-box" >
        <h6>{title}</h6>
        <label class="custom-checkbox">
        <input
          type="checkbox"
          name={name}
          checked={checked}
          onChange={handleItemChange}
        />
      <span class="checkbox-mark"></span>
    </label>
        
    </div>
     );
}

export default ListComp;