import { useState } from "react";
import ListComp from "./ListComp";

function HomePage() {
    const [checkboxes, setCheckboxes] = useState({
        checkbox1: false,
        checkbox2: false,
        checkbox3: false,
        checkbox4: false,
      });
      const [selectAll, setSelectAll] = useState(false);

      const handleItemChange = (event) => {
        const { name, checked } = event.target;
        setCheckboxes((prevItems) => {
          const newCheckedItems = { ...prevItems, [name]: checked };
          setSelectAll(Object.values(newCheckedItems).every((item) => item));
          return newCheckedItems;
        });
      };
    
      const handleSelectAllChange = (event) => {
        const { checked } = event.target;
        setSelectAll(checked);
        setCheckboxes({
            checkbox1: checked,
            checkbox2: checked,
            checkbox3: checked,
            checkbox4: checked,
        });
      };

    return ( 
       <section>
        
        <div className="container-box">
            {/* Page List Header */}


            <ListComp title='All Pages' checked={selectAll} handleItemChange={handleSelectAllChange} name={'selectAll'}/>
            
            {/* Page List Body */}
            <div className="container-body">

            <ListComp title='Page 1' checked={checkboxes?.checkbox1} handleItemChange={handleItemChange} name={'checkbox1'}/>
            <ListComp title='Page 2' checked={checkboxes?.checkbox2} handleItemChange={handleItemChange} name={'checkbox2'}/>
            <ListComp title='Page 3' checked={checkboxes?.checkbox3} handleItemChange={handleItemChange} name={'checkbox3'}/>
            <ListComp title='Page 4' checked={checkboxes?.checkbox4} handleItemChange={handleItemChange} name={'checkbox4'}/>
            
            </div>

{/* Done Button */}

<div className="">
<button className={(checkboxes?.checkbox1 || checkboxes?.checkbox2 || checkboxes?.checkbox3 || checkboxes?.checkbox4)?"done_btn":"done_btn disabled-btn"}>Done</button>
</div>
           
        </div>
       </section>
     );
}

export default HomePage;